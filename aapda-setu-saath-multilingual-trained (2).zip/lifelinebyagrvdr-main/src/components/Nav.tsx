import { Link } from '@tanstack/react-router'
import { HeartPulse, Languages, ChevronDown } from 'lucide-react'
import { useEffect, useState } from 'react'
import { LANGUAGE_GROUPS, type LanguageCode } from '@/lib/i18n'
import { useApp } from '@/hooks/useApp'

export function Nav() {
  const [language, setLanguage] = useState<LanguageCode>('en')
  const [languageMenu, setLanguageMenu] = useState<'choose' | 'national' | 'international' | null>(null)
  useEffect(() => { const saved = localStorage.getItem('lifeline-language') as LanguageCode | null; if (saved) setLanguage(saved) }, [])
  const chooseLanguage = (code: LanguageCode) => { setLanguage(code); localStorage.setItem('lifeline-language', code); setLanguageMenu(null); window.dispatchEvent(new Event('lifeline-language-change')) }
  const demo = useApp((s) => s.demoMode)
  const alarm = useApp((s) => s.alarm.phase)
  const hasVitals = useApp((s) => Object.keys(s.vitals).length > 0)

  const pill =
    alarm !== 'idle'
      ? { text: 'Alarm', cls: 'bg-rose-600 text-white', dot: 'bg-white animate-flash' }
      : demo
        ? { text: 'Demo', cls: 'bg-amber-100 text-amber-900', dot: 'bg-amber-500' }
        : hasVitals
          ? { text: 'Guarding', cls: 'bg-emerald-50 text-emerald-800', dot: 'bg-emerald-500' }
          : { text: 'No device', cls: 'bg-slate-100 text-slate-600', dot: 'bg-slate-400' }

  const link = 'px-3 py-1.5 rounded-full text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition'
  const active = { className: `${link} !bg-slate-900 !text-white` }

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-2 px-4 py-3">
        <Link to="/" className="mr-auto flex items-center gap-2">
          <span className="grid size-8 place-items-center rounded-xl bg-rose-600 text-white shadow-sm shadow-rose-600/30">
            <HeartPulse className="size-4.5" strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-bold tracking-tight">Lifeline</span>
        </Link>
        <nav className="flex items-center gap-1">
          <Link to="/monitor" className={link} activeProps={active}>Monitor</Link>
          <Link to="/saath" className={link} activeProps={active}>Saath</Link>
          <Link to="/contacts" className={link} activeProps={active}>Contacts</Link>
        </nav>
        <div className="relative">
          <button type="button" onClick={() => setLanguageMenu(languageMenu ? null : 'choose')} aria-expanded={Boolean(languageMenu)} className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50" aria-label="Choose language">
            <Languages className="size-4" /><span className="hidden sm:inline">Choose language</span><ChevronDown className="size-3" />
          </button>
          {languageMenu && <div className="absolute right-0 top-full z-50 mt-2 w-64 rounded-2xl border border-slate-200 bg-white p-3 shadow-xl">
            <p className="px-2 pb-2 text-sm font-bold">Choose language</p>
            <div className="grid grid-cols-2 gap-2">
              {LANGUAGE_GROUPS.map(group => <button key={group.id} type="button" onClick={() => setLanguageMenu(group.id)} className={`rounded-xl px-2 py-2 text-left text-xs font-semibold ${languageMenu === group.id ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}>{group.id === 'national' ? '🇮🇳 National languages' : '🌐 International languages'}</button>)}
            </div>
            {LANGUAGE_GROUPS.filter(group => group.id === languageMenu).map(group => <div key={group.id} className="mt-3 grid max-h-64 grid-cols-2 gap-1 overflow-y-auto">
              {group.items.map(([code, native, english]) => <button key={code} type="button" onClick={() => chooseLanguage(code as LanguageCode)} className={`rounded-lg px-2 py-2 text-left text-sm hover:bg-rose-50 ${language === code ? 'bg-rose-50 font-bold text-rose-700 ring-1 ring-rose-200' : 'text-slate-700'}`}><span className="block">{native}</span><span className="block text-[10px] text-slate-400">{english}</span></button>)}
            </div>)}
          </div>}
        </div>
        <span className={`ml-1 hidden items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold sm:flex ${pill.cls}`}>
          <span className={`size-1.5 rounded-full ${pill.dot}`} />
          {pill.text}
        </span>
      </div>
    </header>
  )
}
