import { useState } from 'react'
import { ArrowRight, Building2, Bus, Fuel, GraduationCap, Hospital, Landmark, MapPin, Navigation, Pill, Search, Shield, TrainFront, Route as RouteIcon, Flame, Hotel } from 'lucide-react'
import { useApp } from '@/hooks/useApp'

type Place = { place_id?: number; display_name: string; lat: string; lon: string; type?: string; category?: string }
type RouteInfo = { distance: number; duration: number }

const CATEGORIES = [
  { label: 'Hospitals', query: 'hospital', icon: Hospital },
  { label: 'Police', query: 'police station', icon: Shield },
  { label: 'Fire stations', query: 'fire station', icon: Flame },
  { label: 'Petrol pumps', query: 'petrol pump', icon: Fuel },
  { label: 'Courts', query: 'court', icon: Landmark },
  { label: 'Bus stands', query: 'bus station', icon: Bus },
  { label: 'Railway stations', query: 'railway station', icon: TrainFront },
  { label: 'Pharmacies', query: 'pharmacy', icon: Pill },
  { label: 'Schools', query: 'school', icon: GraduationCap },
  { label: 'Colleges', query: 'college', icon: GraduationCap },
  { label: 'Universities', query: 'university', icon: GraduationCap },
  { label: 'Landmarks', query: 'important landmark', icon: MapPin },
  { label: 'Malls', query: 'shopping mall', icon: Building2 },
  { label: 'Marts & supermarkets', query: 'supermarket mart grocery store', icon: Building2 },
  { label: 'Major hotels', query: 'hotel', icon: Hotel },
]

export function NavigationCard() {
  const fix = useApp((s) => s.location.fix)
  const [query, setQuery] = useState('')
  const [origin, setOrigin] = useState('')
  const [places, setPlaces] = useState<Place[]>([])
  const [selected, setSelected] = useState<Place | null>(null)
  const [route, setRoute] = useState<RouteInfo | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function searchPlaces(text = query) {
    const term = text.trim()
    if (!term) { setError('Enter a city, address, landmark or place to search.'); return }
    setBusy(true); setError(''); setRoute(null); setSelected(null)
    try {
      const url = new URL('https://nominatim.openstreetmap.org/search')
      const categoryTerms: Record<string, string> = {
        'petrol pump': 'fuel station petrol station', 'petrol pumps': 'fuel station petrol station',
        'school': 'school', 'college': 'college', 'university': 'university',
        'school college university': 'school college university',
        'shopping mall': 'shopping mall', 'supermarket mart grocery store': 'supermarket convenience store grocery',
        'pharmacy': 'pharmacy chemist medical store', 'bus station': 'bus station bus terminal',
        'railway station': 'railway station train station', 'police station': 'police station',
        'hospital': 'hospital', 'fire station': 'fire station', 'court': 'courthouse court', 'hotel': 'hotel',
      }
      const normalizedTerm = categoryTerms[term.toLowerCase()] || term
      url.searchParams.set('q', fix && !origin.trim() ? `${normalizedTerm}` : `${normalizedTerm}`)
      url.searchParams.set('format', 'jsonv2')
      url.searchParams.set('limit', '20')
      url.searchParams.set('addressdetails', '1')
      // If GPS is available, constrain nearby category searches to a local bounding box.
      // Never let a generic category query silently return results from another country.
      const categorySearch = Object.keys(categoryTerms).some(k => k.toLowerCase() === term.toLowerCase())
      if (categorySearch && fix) {
        const span = 0.12
        url.searchParams.set('viewbox', `${fix.lng-span},${fix.lat+span},${fix.lng+span},${fix.lat-span}`)
        url.searchParams.set('bounded', '1')
      } else if (categorySearch && !fix && !origin.trim()) {
        setError('Enable GPS or enter a starting city/area first so I can find nearby places instead of guessing your location.')
        setBusy(false)
        return
      }
      if (categorySearch && origin.trim() && !fix) url.searchParams.set('q', `${normalizedTerm} near ${origin.trim()}`)
      const response = await fetch(url.toString(), { headers: { Accept: 'application/json' } })
      if (!response.ok) throw new Error('Place search is temporarily unavailable. Please try again.')
      const data = await response.json() as Place[]
      const sorted = fix && data.length ? [...data].sort((a, b) => {
        const dist = (p: Place) => Math.hypot(Number(p.lat) - fix.lat, (Number(p.lon) - fix.lng) * Math.cos(fix.lat * Math.PI / 180))
        return dist(a) - dist(b)
      }) : data
      setPlaces(sorted.slice(0, 8))
      if (!data.length) setError('No matching places found nearby. Try another nearby category or search a city/area.')
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not search right now.') }
    finally { setBusy(false) }
  }

  async function chooseDestination(place: Place) {
    setSelected(place); setPlaces([]); setRoute(null); setError('')
    if (!fix) return
    try {
      const url = `https://router.project-osrm.org/route/v1/driving/${fix.lng},${fix.lat};${place.lon},${place.lat}?overview=false`
      const response = await fetch(url)
      if (!response.ok) throw new Error('Route preview is unavailable right now.')
      const data = await response.json()
      const r = data.routes?.[0]
      if (r) setRoute({ distance: r.distance, duration: r.duration })
      else setError('No driving route found. You can still open directions in Google Maps.')
    } catch { setError('Could not calculate an in-app route preview. You can still open directions in Google Maps.') }
  }

  const originParam = fix ? `${fix.lat},${fix.lng}` : origin.trim()
  const googleUrl = selected
    ? `https://www.google.com/maps/dir/?api=1&${originParam ? `origin=${encodeURIComponent(originParam)}&` : ''}destination=${encodeURIComponent(`${selected.lat},${selected.lon}`)}&travelmode=driving`
    : ''
  const openMapUrl = selected
    ? `https://www.openstreetmap.org/?mlat=${selected.lat}&mlon=${selected.lon}#map=13/${selected.lat}/${selected.lon}`
    : ''

  return (
    <article className="overflow-hidden rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200 sm:p-6">
      <div className="flex items-center gap-2">
        <span className="grid size-9 place-items-center rounded-xl bg-sky-50 text-sky-700"><Navigation className="size-4" /></span>
        <div><h2 className="font-display text-lg font-bold text-slate-900">Search & navigate</h2><p className="text-xs text-slate-500">Find nearby essentials or search any destination</p></div>
      </div>
      <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); void searchPlaces() }}>
        <div className="relative min-w-0 flex-1"><Search className="absolute left-3 top-3 size-4 text-slate-400"/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="City, address, hospital, landmark…" className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100" aria-label="Search any destination" /></div>
        <button type="submit" disabled={busy} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">{busy ? 'Searching…' : 'Search'}</button>
      </form>
      {!fix && <label className="mt-3 block text-xs text-slate-600">Starting point (or enable live GPS above)<input value={origin} onChange={(e) => setOrigin(e.target.value)} placeholder="e.g. Rohtak, Haryana" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-sky-500" /></label>}
      <p className="mt-2 text-[11px] text-slate-500">Nearby essentials (closest first when GPS is available)</p>
      <div className="mt-2 flex gap-2 overflow-x-auto pb-2">
        {CATEGORIES.map((c) => { const Icon = c.icon; return <button key={c.label} onClick={() => { setQuery(c.query); void searchPlaces(c.query) }} className="flex shrink-0 items-center gap-1.5 rounded-full bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-sky-50 hover:text-sky-800"><Icon className="size-3.5"/>{c.label}</button> })}
      </div>
      {error && <p role="status" className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900">{error}</p>}
      {places.length > 0 && <div className="mt-3 divide-y divide-slate-100 rounded-2xl border border-slate-200">{places.map((p, i) => <button key={`${p.place_id ?? p.lat}-${p.lon}-${i}`} onClick={() => void chooseDestination(p)} className="flex w-full items-start gap-3 p-3 text-left hover:bg-slate-50"><MapPin className="mt-0.5 size-4 shrink-0 text-sky-600"/><span className="text-sm text-slate-700">{p.display_name}</span><ArrowRight className="ml-auto mt-0.5 size-4 shrink-0 text-slate-400"/></button>)}</div>}
      {selected && <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200">
        <div className="flex items-start gap-3 p-4"><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-emerald-50 text-emerald-700"><MapPin className="size-4"/></span><div className="min-w-0 flex-1"><h3 className="text-sm font-bold text-slate-900">Destination selected</h3><p className="mt-1 text-xs leading-relaxed text-slate-600">{selected.display_name}</p>{route && <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-slate-800"><RouteIcon className="size-4"/>{(route.distance / 1000).toFixed(1)} km · about {Math.max(1, Math.round(route.duration / 60))} min by road</p>}<p className="mt-2 text-[11px] text-slate-500">Turn-by-turn guidance opens in Google Maps. Route estimates can change with traffic and road conditions.</p></div></div>
        <div className="grid grid-cols-2 gap-2 p-3 pt-0"><a href={googleUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-sky-700 px-3 py-3 text-center text-xs font-bold text-white"><Navigation className="size-4"/>Start navigation</a><a href={openMapUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-3 py-3 text-center text-xs font-bold text-slate-700">View map</a></div>
      </div>}
      <p className="mt-3 text-[10px] leading-relaxed text-slate-400">Nearby category searches are bounded around your GPS location when available. Place search uses OpenStreetMap Nominatim; route previews use the public OSRM demo service. These services have usage limits and are not guaranteed for emergency-critical navigation. Google Maps opens for turn-by-turn guidance.</p>
    </article>
  )
}
