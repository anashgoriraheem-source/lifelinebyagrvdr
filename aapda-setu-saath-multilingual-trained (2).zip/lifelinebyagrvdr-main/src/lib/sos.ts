/**
 * Builds the emergency message and the one-tap links that hand it to the
 * phone's own dialer and messaging apps. Nothing is sent silently: the
 * person confirms in their messaging app. Server-side SMS/voice via
 * Twilio arrives in a later milestone (see PLAN.md).
 */
import type { AlarmReason, LocationFix } from './types'

export const mapsLink = (f: LocationFix) => `https://maps.google.com/?q=${f.lat.toFixed(6)},${f.lng.toFixed(6)}`

export const clockTime = (t: number) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

export interface EmergencyProfile {
  name?: string
  age?: string | number
  gender?: string
  bloodType?: string
  conditions?: string
  allergies?: string
  medications?: string
}

const profileValue = (value: unknown) => {
  if (typeof value !== 'string' && typeof value !== 'number') return ''
  const clean = String(value).trim()
  return !clean || /^not provided$/i.test(clean) ? '' : clean
}

/** Always build alerts from the user's saved profile, never demo/fixture identity data. */
export function getEmergencyProfile(): EmergencyProfile {
  if (typeof window === 'undefined') return {}
  try {
    const raw = window.localStorage.getItem('aapda-setu-emergency-profile')
    if (!raw) return {}
    const saved = JSON.parse(raw) as EmergencyProfile
    if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {}
    // Read only the saved, user-entered profile. Never fall back to fixture/demo patient data.
    return {
      name: profileValue(saved.name), age: profileValue(saved.age), gender: profileValue(saved.gender),
      bloodType: profileValue(saved.bloodType), conditions: profileValue(saved.conditions),
      allergies: profileValue(saved.allergies), medications: profileValue(saved.medications),
    }
  } catch {
    return {}
  }
}

export function buildSosMessage(reason: AlarmReason | null, fix: LocationFix | null, opts: { test?: boolean } = {}) {
  const p = getEmergencyProfile()
  const name = profileValue(p.name) || 'Patient details unavailable'
  const age = profileValue(p.age)
  const bloodType = profileValue(p.bloodType)
  const gender = profileValue(p.gender)
  const identity = [age, gender, bloodType ? `blood ${bloodType}` : ''].filter(Boolean).join(', ')
  const lines = [
    `${opts.test ? '[TEST — no action needed] ' : ''}EMERGENCY: ${name}${identity ? ` (${identity})` : ''} needs help.`,
    reason ? `Reason: ${reason.label} — ${reason.reading} at ${clockTime(Date.now())}.` : 'Reason: SOS pressed.',
    fix
      ? `Location: ${mapsLink(fix)} (±${Math.round(fix.accuracy)} m, ${clockTime(fix.at)})`
      : 'Location: unavailable — please call.',
  ]
  const conditions = profileValue(p.conditions)
  const allergies = profileValue(p.allergies)
  const medications = profileValue(p.medications)
  if (conditions || allergies || medications) {
    lines.push(`Conditions: ${conditions || 'Not provided'}. Allergies: ${allergies || 'Not provided'}. Meds: ${medications || 'Not provided'}.`)
  }
  lines.push('Sent via Aapda Setu.')
  return lines.join('\n')
}

const digits = (phone: string) => phone.replace(/[^\d+]/g, '')

const isApple = () => typeof navigator !== 'undefined' && /iPad|iPhone|iPod|Macintosh/.test(navigator.userAgent)

export function smsHref(phones: string[], body: string) {
  const to = phones.map(digits).join(',')
  return `sms:${to}${isApple() ? '&' : '?'}body=${encodeURIComponent(body)}`
}

export const telHref = (phone: string) => `tel:${digits(phone)}`

export function isValidPhone(phone: string) {
  const d = digits(phone)
  return /^\+?\d{3,15}$/.test(d)
}
