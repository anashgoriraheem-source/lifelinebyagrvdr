/** Single shared SOS audio source. Never layer a generated tone over the uploaded alarm. */
let alarmAudio: HTMLAudioElement | null = null
let active = false
let pausedForSpeech = false
let vibrationTimer: ReturnType<typeof setInterval> | null = null

function getAudio() {
  if (typeof window === 'undefined') return null
  if (!alarmAudio) {
    alarmAudio = new Audio('/sos_765hz.wav')
    alarmAudio.loop = true
    alarmAudio.preload = 'auto'
    alarmAudio.volume = 1
  }
  return alarmAudio
}

export function startSiren() {
  active = true
  pausedForSpeech = false
  const audio = getAudio()
  if (audio) {
    audio.volume = 1
    if (audio.paused) {
      void audio.play().catch(() => {
        // Browsers may require a user gesture; keep the emergency screen visible.
      })
    }
  }
  if (typeof navigator !== 'undefined' && navigator.vibrate && !vibrationTimer) {
    navigator.vibrate([350, 120, 350, 180])
    vibrationTimer = setInterval(() => {
      if (active && !pausedForSpeech) navigator.vibrate?.([350, 120, 350, 180])
    }, 1000)
  }
}

/** Pause only while Pukar speaks; keep the emergency alarm logically active. */
export function pauseSirenForSpeech() {
  if (!active) return
  pausedForSpeech = true
  getAudio()?.pause()
  if (vibrationTimer) clearInterval(vibrationTimer)
  vibrationTimer = null
  navigator.vibrate?.(0)
}

export function resumeSirenAfterSpeech() {
  if (!active || !pausedForSpeech) return
  pausedForSpeech = false
  const audio = getAudio()
  if (audio) void audio.play().catch(() => {})
  if (typeof navigator !== 'undefined' && navigator.vibrate && !vibrationTimer) {
    navigator.vibrate([350, 120, 350, 180])
    vibrationTimer = setInterval(() => {
      if (active && !pausedForSpeech) navigator.vibrate?.([350, 120, 350, 180])
    }, 1000)
  }
}

/** Stop everything immediately, including when the user marks themselves safe. */
export function stopSiren() {
  active = false
  pausedForSpeech = false
  const audio = getAudio()
  if (audio) {
    audio.pause()
    try { audio.currentTime = 0 } catch { /* media may not be ready yet */ }
  }
  if (vibrationTimer) clearInterval(vibrationTimer)
  vibrationTimer = null
  if (typeof navigator !== 'undefined') navigator.vibrate?.(0)
}

/** Short tick used by the CPR metronome; suppressed while the SOS alarm is active. */
export function tick() {
  if (active) return
  try {
    const ctx = new AudioContext()
    const o = ctx.createOscillator()
    const g = ctx.createGain()
    o.type = 'sine'
    o.frequency.value = 1200
    g.gain.value = 0.12
    o.connect(g).connect(ctx.destination)
    o.start()
    o.stop(ctx.currentTime + 0.05)
    o.onended = () => void ctx.close()
  } catch { /* audio unavailable */ }
}
