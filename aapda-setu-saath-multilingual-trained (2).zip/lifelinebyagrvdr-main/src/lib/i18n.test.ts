import { describe, expect, it } from 'vitest'
import { LANGUAGE_GROUPS, translateText, type LanguageCode } from './i18n'

describe('multilingual phrasebook', () => {
  it('offers the requested 9 national and 9 international languages', () => {
    expect(LANGUAGE_GROUPS.find((g) => g.id === 'national')?.items).toHaveLength(9)
    expect(LANGUAGE_GROUPS.find((g) => g.id === 'international')?.items).toHaveLength(9)
  })

  it('translates shared UI phrases across the supported language codes', () => {
    const codes: LanguageCode[] = ['hi','pa','kn','ur','ml','mr','gu','or','as','en','ja','ru','zh','it','fr','de','ko','ar']
    for (const code of codes) {
      expect(translateText('Choose language', code).trim().length).toBeGreaterThan(0)
      expect(translateText('No device connected', code).trim().length).toBeGreaterThan(0)
    }
    expect(translateText('No device connected', 'hi')).toBe('कोई डिवाइस कनेक्ट नहीं है')
    expect(translateText('No device connected', 'ja')).toBe('デバイスが接続されていません')
    expect(translateText('No device connected', 'ar')).toBe('لا يوجد جهاز متصل')
  })

  it('preserves surrounding whitespace and leaves unknown text unchanged', () => {
    expect(translateText('  Save  ', 'hi')).toBe('  सहेजें  ')
    expect(translateText('A new sentence not in the phrasebook.', 'hi')).toBe('A new sentence not in the phrasebook.')
  })

  it('translates full homepage and emergency disclaimer copy for every locale', () => {
    const codes: LanguageCode[] = ['hi','pa','kn','ur','ml','mr','gu','or','as','en','ja','ru','zh','it','fr','de','ko','ar']
    const longCopy = 'It watches your vitals, spots falls, and shares your live location with police, ambulance and family — then talks you through first aid, step by step, until help arrives.'
    for (const code of codes.filter((c) => c !== 'en')) {
      expect(translateText(longCopy, code)).not.toBe(longCopy)
      expect(translateText('Lifeline — automatic emergency response', code)).not.toBe('Lifeline — automatic emergency response')
    }
  })


  it('translates critical SOS and motion messages in every supported non-English locale', () => {
    const codes: LanguageCode[] = ['hi','pa','kn','ur','ml','mr','gu','or','as','ja','ru','zh','it','fr','de','ko','ar']
    const phrases = [
      'Emergency detected',
      'Get help now',
      'Keep holding…',
      "I'm OK — hold to cancel",
      'Enable motion sensor',
      'Simulate fall',
      'Fall & jolt sensor',
      'Detects free-fall → impact → 10 s of stillness, and violent jolts. Works while this page is open on your phone.',
    ]
    for (const phrase of phrases) for (const code of codes) {
      expect(translateText(phrase, code), `${phrase} should be translated for ${code}`).not.toBe(phrase)
    }
  })

  it('keeps English unchanged', () => {
    expect(translateText('No device connected', 'en')).toBe('No device connected')
  })
})
