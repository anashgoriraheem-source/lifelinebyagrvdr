import { createFileRoute, Link, useNavigate, useSearch } from '@tanstack/react-router'
import { ArrowLeft, CheckCircle2, Clock3, LockKeyhole, Mail, RefreshCw, ShieldCheck } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'

export const Route = createFileRoute('/verify-email')({
  component: VerifyEmailPage,
})

const OTP_SECONDS = 180
const RESEND_SECONDS = 60
const LOCK_SECONDS = 15 * 60
const MAX_ATTEMPTS = 5

function formatTime(seconds: number) {
  const safe = Math.max(0, seconds)
  return `${String(Math.floor(safe / 60)).padStart(2, '0')}:${String(safe % 60).padStart(2, '0')}`
}

function maskEmail(email: string) {
  const [name, domain] = email.split('@')
  if (!name || !domain) return email
  const visible = name.length < 3 ? name.slice(0, 1) : name.slice(0, 2)
  return `${visible}${'•'.repeat(Math.max(2, Math.min(6, name.length - visible.length)))}@${domain}`
}

function VerifyEmailPage() {
  const search = useSearch({ strict: false }) as { email?: string }
  const navigate = useNavigate()
  const [email, setEmail] = useState(search.email ?? '')
  const [code, setCode] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [otpRemaining, setOtpRemaining] = useState(OTP_SECONDS)
  const [resendRemaining, setResendRemaining] = useState(0)
  const [lockRemaining, setLockRemaining] = useState(0)
  const [attempts, setAttempts] = useState(0)
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState<'error' | 'success' | 'info'>('info')
  const [showDemoNote, setShowDemoNote] = useState(true)

  useEffect(() => {
    const timer = window.setInterval(() => {
      setOtpRemaining(value => Math.max(0, value - 1))
      setResendRemaining(value => Math.max(0, value - 1))
      setLockRemaining(value => Math.max(0, value - 1))
    }, 1000)
    return () => window.clearInterval(timer)
  }, [])

  const canUseEmail = useMemo(() => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()), [email])
  const locked = lockRemaining > 0

  const requestCode = () => {
    if (!canUseEmail) {
      setMessage('Enter a valid email address to continue.')
      setMessageType('error')
      return
    }
    if (resendRemaining > 0 && codeSent) return
    setCodeSent(true)
    setCode('')
    setOtpRemaining(OTP_SECONDS)
    setResendRemaining(RESEND_SECONDS)
    setMessage('Verification screen ready. Email delivery will work after the secure server is configured.')
    setMessageType('info')
  }

  const verifyCode = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (locked) return
    if (otpRemaining <= 0) {
      setMessage('This code has expired. Request a new code to continue.')
      setMessageType('error')
      return
    }
    if (!/^\d{6}$/.test(code)) {
      setMessage('Enter all 6 digits of the verification code.')
      setMessageType('error')
      return
    }
    // Front-end preview only: this fixed code is NOT real email verification.
    // Replace this branch with server-side OTP verification before production use.
    if (code === '123456') {
      setMessage('Demo verification complete. Let’s set up your emergency profile…')
      setMessageType('success')
      window.setTimeout(() => { void navigate({ to: '/profile' }) }, 700)
      return
    }
    const nextAttempts = attempts + 1
    setAttempts(nextAttempts)
    if (nextAttempts >= MAX_ATTEMPTS) {
      setLockRemaining(LOCK_SECONDS)
      setMessage('Too many incorrect attempts. Verification is temporarily locked for 15 minutes.')
      setMessageType('error')
      return
    }
    setMessage(`${MAX_ATTEMPTS - nextAttempts} attempt${MAX_ATTEMPTS - nextAttempts === 1 ? '' : 's'} remaining. For this front-end preview, use the demo code shown below.`)
    setMessageType('error')
  }

  return (
    <main className="relative min-h-[calc(100vh-64px)] overflow-hidden px-4 py-10 sm:py-16">
      <div className="pointer-events-none absolute -left-32 -top-28 size-80 rounded-full bg-rose-200/50 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-36 -right-24 size-96 rounded-full bg-orange-100/70 blur-3xl" />
      <div className="relative mx-auto grid w-full max-w-5xl overflow-hidden rounded-[2rem] bg-white shadow-xl shadow-slate-900/5 ring-1 ring-slate-200/80 lg:grid-cols-[0.9fr_1.1fr]">
        <aside className="relative hidden flex-col justify-between overflow-hidden bg-slate-950 p-10 text-white lg:flex">
          <div className="absolute -right-20 top-24 size-64 rounded-full border border-white/10" />
          <div className="absolute -right-8 top-36 size-40 rounded-full border border-white/10" />
          <div className="relative flex items-center gap-3">
            <img src="/aapda-setu-logo.png" alt="Aapda Setu logo" className="size-14 rounded-2xl object-cover ring-1 ring-white/20" />
            <div><p className="font-display text-xl font-extrabold">Aapda Setu</p><p className="text-xs text-slate-400">Prepared. Connected. Safer.</p></div>
          </div>
          <div className="relative py-12">
            <div className="mb-6 grid size-16 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/15"><Mail className="size-8 text-rose-300" /></div>
            <h1 className="font-display text-4xl font-extrabold leading-tight">One quick check. A safer account.</h1>
            <p className="mt-4 max-w-sm leading-7 text-slate-300">Verify your email to continue setting up your emergency-ready profile.</p>
          </div>
          <div className="relative flex items-center gap-2 text-xs text-slate-400"><LockKeyhole className="size-4" /> Your verification code should stay private.</div>
        </aside>

        <section className="p-6 sm:p-10 lg:p-12">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 transition hover:text-slate-900"><ArrowLeft className="size-4" /> Back to home</Link>
          <div className="mt-8 lg:mt-12">
            <div className="mb-5 grid size-14 place-items-center rounded-2xl bg-rose-50 text-rose-600 ring-1 ring-rose-100 lg:hidden"><ShieldCheck className="size-7" /></div>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-rose-600">Email verification</p>
            <h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Verify your email</h2>
            <p className="mt-3 max-w-md leading-6 text-slate-600">We’ll use a one-time code to confirm it’s really you. The code expires after 3 minutes.</p>
          </div>

          <div className="mt-8">
            <label htmlFor="verify-email" className="mb-2 block text-sm font-bold text-slate-800">Email address</label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-slate-400" />
              <input id="verify-email" type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3.5 pl-12 pr-4 text-base outline-none transition placeholder:text-slate-400 focus:border-rose-400 focus:bg-white focus:ring-4 focus:ring-rose-100" />
            </div>
            {codeSent && <p className="mt-2 text-xs text-slate-500">Code destination: <span className="font-semibold text-slate-700">{maskEmail(email)}</span></p>}
          </div>

          {!codeSent ? (
            <button type="button" onClick={requestCode} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-rose-600 px-5 py-3.5 font-bold text-white shadow-lg shadow-rose-600/20 transition hover:bg-rose-700 focus:outline-none focus:ring-4 focus:ring-rose-200"><Mail className="size-4" /> Send verification code</button>
          ) : (
            <form onSubmit={verifyCode} className="mt-7">
              <div className="mb-3 flex items-center justify-between gap-3"><label htmlFor="otp-code" className="text-sm font-bold text-slate-800">6-digit verification code</label><span className={`inline-flex items-center gap-1.5 text-xs font-semibold ${otpRemaining === 0 ? 'text-rose-600' : 'text-slate-500'}`}><Clock3 className="size-3.5" />{otpRemaining === 0 ? 'Code expired' : `Expires in ${formatTime(otpRemaining)}`}</span></div>
              <input id="otp-code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={event => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))} placeholder="••••••" aria-describedby="otp-help" className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-center font-mono text-3xl font-bold tracking-[0.55em] text-slate-900 outline-none transition placeholder:text-slate-300 focus:border-rose-400 focus:bg-white focus:ring-4 focus:ring-rose-100" />
              <p id="otp-help" className="mt-2 text-xs leading-5 text-slate-500">Never share your code with anyone. You have up to 5 incorrect attempts.</p>
              <button type="submit" disabled={locked || otpRemaining === 0 || code.length !== 6} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-rose-600 px-5 py-3.5 font-bold text-white shadow-lg shadow-rose-600/20 transition hover:bg-rose-700 focus:outline-none focus:ring-4 focus:ring-rose-200 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"><CheckCircle2 className="size-4" /> Verify email</button>
              <div className="mt-4 flex flex-col items-center gap-3 text-sm sm:flex-row sm:justify-between">
                <button type="button" onClick={requestCode} disabled={resendRemaining > 0 || locked} className="inline-flex items-center gap-2 font-semibold text-rose-700 hover:text-rose-900 disabled:cursor-not-allowed disabled:text-slate-400"><RefreshCw className="size-4" />{resendRemaining > 0 ? `Resend code in ${formatTime(resendRemaining)}` : 'Resend code'}</button>
                <button type="button" onClick={() => { setCodeSent(false); setCode(''); setMessage(''); setMessageType('info') }} className="font-semibold text-slate-500 hover:text-slate-800">Change email</button>
              </div>
              {locked && <p className="mt-4 rounded-xl bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-700">Try again in {formatTime(lockRemaining)}.</p>}
            </form>
          )}

          {message && <p role="status" aria-live="polite" className={`mt-5 rounded-xl px-4 py-3 text-sm leading-5 ${messageType === 'error' ? 'bg-rose-50 text-rose-700' : messageType === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-sky-50 text-sky-800'}`}>{message}</p>}

          {showDemoNote && <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-5 text-amber-900"><p className="font-bold">Setup note</p><p className="mt-1">Front-end preview only: use demo code <strong>123456</strong> to open the normal interface. Real Gmail delivery and secure OTP verification are not connected yet; they require a secure server and configured sender.</p><button type="button" onClick={() => setShowDemoNote(false)} className="mt-2 text-xs font-bold underline underline-offset-2">Dismiss note</button></div>}

          <div className="mt-8 flex items-start gap-3 border-t border-slate-100 pt-5 text-xs leading-5 text-slate-500"><LockKeyhole className="mt-0.5 size-4 shrink-0" /><p>For your security, OTP expiry, resend limits, and failed-attempt locks must also be enforced by the server, not just this page.</p></div>
        </section>
      </div>
    </main>
  )
}
