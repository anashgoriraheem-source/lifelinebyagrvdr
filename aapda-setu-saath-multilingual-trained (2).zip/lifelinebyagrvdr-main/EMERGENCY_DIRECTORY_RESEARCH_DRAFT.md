# Aapda Setu Emergency Directory — Research Draft v1

This ZIP adds a source/reference field to emergency-service records and populates an initial batch of countries from the ITU E.129 database and ITU-published numbering information, plus India's Government of India helpline directory. It is NOT a complete, production-verified directory.

## Important safety notes
- Blank numbers display as “Not verified”; they must not be guessed.
- Some source pages are old. A source link is provenance, not proof the number is still active.
- SMS emergency availability is left blank unless specifically researched; a phone's ability to send SMS does not mean an emergency centre accepts it.
- Country/territory entries are not all sovereign countries; the alphabetical selector follows the ISO-style list already in the project.
- Before production, verify each service number with current national police, ambulance, fire/rescue or government sources, record verification date, and test call-routing behavior. Never auto-dial unverified emergency numbers.

## Research references
- ITU E.129: https://www.itu.int/net/itu-t/inrdb/e129_important_numbers.aspx
- Government of India helpline directory: https://www.india.gov.in/directory/helpline
- ITU Operational Bulletin archive: https://www.ituob.org/issues/

## Countries with an added source note in this draft
Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Ethiopia, The Gambia, India, Iraq, Kenya, Mauritius, Seychelles, Switzerland and Türkiye.

## Batch 1 progress (A–E)
A secondary comparative directory was used to prefill additional candidate numbers for alphabetically early entries. These additions are explicitly marked as secondary-source research and are NOT official verification. Blank general numbers mean the source did not list a distinct all-service number. SMS remains blank unless separately verified.

Secondary cross-check reference: https://tools.thelawtoknow.com/emergency-numbers (page notes that only a subset of entries were confirmed and other entries come from public lists).
