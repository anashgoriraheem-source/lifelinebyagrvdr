"""Compatibility entry point. The canonical trainer is train_saath_multilingual.py."""
import os
import runpy

script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "train_saath_multilingual.py")
runpy.run_path(script, run_name="__main__")
