# Motion sensor and live location troubleshooting

## Important safety note
This is a prototype. Fall/jolt detection is a heuristic and is not a certified medical or crash-detection system. Do not rely on it as the only way to contact emergency services. Test only in safe, controlled conditions; do not throw or drop the phone to trigger it.

## Live location
- Open the deployed site directly in a browser using HTTPS (not an embedded preview or an HTTP page).
- On Android, turn on device Location/GPS and allow location access for the browser/site. On iPhone, allow Location access for Safari and enable Precise Location if available.
- Tap **Start tracking** and accept the browser prompt. If it times out, the card now reports a reason and **Retry location** starts a fresh geolocation watch.
- Indoor GPS can be slow or inaccurate. Try near a window or outdoors. The map requires an internet connection to load OpenStreetMap tiles.
- Browser geolocation does not guarantee background tracking when the tab is closed or the phone is locked.

## Motion sensor
- Open the page directly in the latest Chrome on Android or Safari on iOS over HTTPS; embedded website previews may block sensor APIs.
- Tap **Enable motion sensor** and accept any prompt. Keep the page open and visible.
- The card now distinguishes permission granted from actual incoming sensor readings. If no samples arrive, it shows troubleshooting guidance and a retry button.
- Some browsers/devices block or do not expose motion events. A web page cannot force-enable those sensors or reliably monitor while closed/backgrounded.

## Before real-world use
- Verify behavior on the actual target phone/browser, with permissions granted.
- Test GPS by checking the displayed coordinates against a known safe location.
- Test motion diagnostics by gently moving the phone; do not simulate a fall or dangerous impact.
- Do not send automatic emergency calls/SMS until numbers, consent, false-positive handling, and platform behavior are independently tested.
